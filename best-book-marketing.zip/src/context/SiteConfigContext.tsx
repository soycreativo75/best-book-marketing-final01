import React, { createContext, useContext, useState } from 'react';
import {
  SiteConfig,
  PortfolioCover,
  TestimonialItem,
  BooktrailerItem,
  ServiceItem,
  FAQItem,
  LeadSubmission,
  SectionsVisibility,
} from '../types';
import {
  PORTFOLIO_COVERS,
  TESTIMONIALS_DATA,
  BOOKTRAILERS_DATA,
  SERVICES_DATA,
  INITIAL_FAQS,
} from '../data/content';

export const DEFAULT_SITE_CONFIG: SiteConfig = {
  // Logotipos
  logoWhiteUrl: '',
  logoBlackUrl: '',
  logoUseCustomOnly: false,

  // Hero Textos
  heroBadge: 'Agencia Nº 1 en Lanzamientos KDP & Bestsellers',
  heroTitleLine1: 'Lanza tu Libro en Amazon KDP y Conviértelo en',
  heroTitleHighlight: 'Bestseller Internacional',
  heroSubtitle:
    'Diseño de portadas cinematográficas, maquetación de imprenta de lujo y estrategias de posicionamiento para que tu libro lidere su categoría en Amazon.',
  heroCtaText: 'Comenzar Mi Proyecto',
  heroSecondaryCtaText: 'Calcular Mis Regalías',

  // Estadísticas Hero
  statsTopBooks: '+180',
  statsRoyalties: '100%',
  statsRating: '4.9 / 5',

  // Contacto & Información
  whatsappNumber: '+34612345678',
  whatsappMessage:
    'Hola, me gustaría información para publicar y posicionar mi libro en Amazon KDP con Best Book Marketing.',
  contactEmail: 'soycreativo2023@gmail.com',
  notificationEmail: 'soycreativo2023@gmail.com', // Correo receptor principal
  contactPhone: '+34 910 000 000',
  officeAddress: 'Paseo de la Castellana 95, Planta 14, 28046 Madrid, España',
  businessHours: 'Lunes a Viernes: 09:00 - 19:00 (CET / Madrid)',
  instagramUrl: 'https://instagram.com',
  linkedinUrl: 'https://linkedin.com',
  youtubeUrl: 'https://youtube.com',

  // Precios y Planes
  planStarterPrice: 490,
  planProPrice: 890,
  planElitePrice: 1490,
  planStarterTitle: 'Lanzamiento Esencial KDP',
  planProTitle: 'Bestseller Authority Pro',
  planEliteTitle: 'Campaña Integral 360',

  // Secciones Activas / Apagadas
  sectionsVisibility: {
    hero: true,
    portfolioCovers: true,
    services: true,
    booktrailers: true,
    royaltyCalculator: true,
    testimonials: true,
    pricing: true,
    contact: true,
    footer: true,
  },

  // Contenidos dinámicos administrables
  portfolioCovers: PORTFOLIO_COVERS,
  testimonials: TESTIMONIALS_DATA,
  booktrailers: BOOKTRAILERS_DATA,
  services: SERVICES_DATA,
  faqs: INITIAL_FAQS,

  // Bandeja de Leads inicial
  leadsInbox: [
    {
      id: 'lead-sample-1',
      createdAt: new Date(Date.now() - 3600000 * 2).toISOString(),
      source: 'contact_form',
      name: 'Gabriel Morales',
      email: 'g.morales@ejemplo.com',
      phone: '+34 654 321 098',
      genre: 'No-Ficción / Negocios',
      manuscriptStatus: 'Manuscrito Terminado',
      message: 'Busco publicar mi libro de finanzas para pymes en tapa blanda y digital antes de fin de año.',
      status: 'new',
    },
  ],
};

interface SiteConfigContextType {
  config: SiteConfig;
  updateConfig: (newConfig: Partial<SiteConfig>) => void;
  resetConfig: () => void;
  // Toggles de secciones
  toggleSection: (sectionKey: keyof SectionsVisibility) => void;
  // Leads Inbox
  addLead: (lead: Omit<LeadSubmission, 'id' | 'createdAt' | 'status'>) => void;
  updateLeadStatus: (id: string, status: LeadSubmission['status']) => void;
  deleteLead: (id: string) => void;
  clearAllLeads: () => void;
  // Portadas
  addOrUpdateCover: (cover: PortfolioCover) => void;
  deleteCover: (id: number) => void;
  // Testimonios
  addOrUpdateTestimonial: (testimonial: TestimonialItem) => void;
  deleteTestimonial: (id: number) => void;
  // Booktrailers
  addOrUpdateBooktrailer: (trailer: BooktrailerItem) => void;
  deleteBooktrailer: (id: number) => void;
  // Servicios
  addOrUpdateService: (service: ServiceItem) => void;
  deleteService: (id: number) => void;
  // FAQs
  addOrUpdateFaq: (faq: FAQItem) => void;
  deleteFaq: (id: string) => void;
}

const SiteConfigContext = createContext<SiteConfigContextType | undefined>(undefined);

const STORAGE_KEY = 'bbm_site_configuration_v3';

export const SiteConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<SiteConfig>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_SITE_CONFIG,
          ...parsed,
          sectionsVisibility: {
            ...DEFAULT_SITE_CONFIG.sectionsVisibility,
            ...(parsed.sectionsVisibility || {}),
          },
          portfolioCovers: parsed.portfolioCovers || DEFAULT_SITE_CONFIG.portfolioCovers,
          testimonials: parsed.testimonials || DEFAULT_SITE_CONFIG.testimonials,
          booktrailers: parsed.booktrailers || DEFAULT_SITE_CONFIG.booktrailers,
          services: parsed.services || DEFAULT_SITE_CONFIG.services,
          faqs: parsed.faqs || DEFAULT_SITE_CONFIG.faqs,
          leadsInbox: parsed.leadsInbox || DEFAULT_SITE_CONFIG.leadsInbox,
        };
      }
    } catch {
      // Fallback
    }
    return DEFAULT_SITE_CONFIG;
  });

  const saveToStorage = (updated: SiteConfig) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
    } catch (err) {
      console.error('Error saving config to localStorage:', err);
    }
  };

  const updateConfig = (newConfig: Partial<SiteConfig>) => {
    setConfig((prev) => {
      const updated = { ...prev, ...newConfig };
      saveToStorage(updated);
      return updated;
    });
  };

  const resetConfig = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
    setConfig(DEFAULT_SITE_CONFIG);
  };

  const toggleSection = (sectionKey: keyof SectionsVisibility) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        sectionsVisibility: {
          ...prev.sectionsVisibility,
          [sectionKey]: !prev.sectionsVisibility[sectionKey],
        },
      };
      saveToStorage(updated);
      return updated;
    });
  };

  const addLead = (leadData: Omit<LeadSubmission, 'id' | 'createdAt' | 'status'>) => {
    const newLead: LeadSubmission = {
      ...leadData,
      id: 'lead-' + Date.now(),
      createdAt: new Date().toISOString(),
      status: 'new',
    };

    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        leadsInbox: [newLead, ...(prev.leadsInbox || [])],
      };
      saveToStorage(updated);
      return updated;
    });

    // Intentar abrir cliente de correo automáticamente con el contenido estructurado
    try {
      const subject = encodeURIComponent(`[Nuevo Lead Best Book Marketing] - ${newLead.name}`);
      const body = encodeURIComponent(
        `Nuevo lead recibido desde el sitio web:\n\n` +
          `Nombre: ${newLead.name}\n` +
          `Correo: ${newLead.email}\n` +
          `Teléfono: ${newLead.phone || 'No indicado'}\n` +
          `Género: ${newLead.genre || 'No indicado'}\n` +
          `Estado manuscrito: ${newLead.manuscriptStatus || 'No indicado'}\n` +
          `Origen: ${newLead.source === 'contact_form' ? 'Formulario de Contacto' : 'Modal de Sesión Estratégica'}\n` +
          `Mensaje:\n${newLead.message || 'Sin mensaje adicional'}\n\n` +
          `Fecha: ${new Date().toLocaleString()}\n` +
          `Destino configurado: ${config.notificationEmail}`
      );
      const mailtoUrl = `mailto:${config.notificationEmail}?subject=${subject}&body=${body}`;
      
      // Crear enlace invisible para invocar el cliente de correo sin bloquear la UI
      const link = document.createElement('a');
      link.href = mailtoUrl;
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => document.body.removeChild(link), 300);
    } catch (err) {
      console.warn('Mailto link error:', err);
    }
  };

  const updateLeadStatus = (id: string, status: LeadSubmission['status']) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        leadsInbox: prev.leadsInbox.map((lead) => (lead.id === id ? { ...lead, status } : lead)),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  const deleteLead = (id: string) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        leadsInbox: prev.leadsInbox.filter((lead) => lead.id !== id),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  const clearAllLeads = () => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        leadsInbox: [],
      };
      saveToStorage(updated);
      return updated;
    });
  };

  // CRUD Portadas
  const addOrUpdateCover = (cover: PortfolioCover) => {
    setConfig((prev) => {
      const exists = prev.portfolioCovers.some((c) => c.id === cover.id);
      const updatedCovers = exists
        ? prev.portfolioCovers.map((c) => (c.id === cover.id ? cover : c))
        : [...prev.portfolioCovers, cover];
      const updated: SiteConfig = { ...prev, portfolioCovers: updatedCovers };
      saveToStorage(updated);
      return updated;
    });
  };

  const deleteCover = (id: number) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        portfolioCovers: prev.portfolioCovers.filter((c) => c.id !== id),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  // CRUD Testimonios
  const addOrUpdateTestimonial = (testimonial: TestimonialItem) => {
    setConfig((prev) => {
      const exists = prev.testimonials.some((t) => t.id === testimonial.id);
      const updatedItems = exists
        ? prev.testimonials.map((t) => (t.id === testimonial.id ? testimonial : t))
        : [...prev.testimonials, testimonial];
      const updated: SiteConfig = { ...prev, testimonials: updatedItems };
      saveToStorage(updated);
      return updated;
    });
  };

  const deleteTestimonial = (id: number) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        testimonials: prev.testimonials.filter((t) => t.id !== id),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  // CRUD Booktrailers
  const addOrUpdateBooktrailer = (trailer: BooktrailerItem) => {
    setConfig((prev) => {
      const exists = prev.booktrailers.some((b) => b.id === trailer.id);
      const updatedItems = exists
        ? prev.booktrailers.map((b) => (b.id === trailer.id ? trailer : b))
        : [...prev.booktrailers, trailer];
      const updated: SiteConfig = { ...prev, booktrailers: updatedItems };
      saveToStorage(updated);
      return updated;
    });
  };

  const deleteBooktrailer = (id: number) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        booktrailers: prev.booktrailers.filter((b) => b.id !== id),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  // CRUD Servicios
  const addOrUpdateService = (service: ServiceItem) => {
    setConfig((prev) => {
      const exists = prev.services.some((s) => s.id === service.id);
      const updatedItems = exists
        ? prev.services.map((s) => (s.id === service.id ? service : s))
        : [...prev.services, service];
      const updated: SiteConfig = { ...prev, services: updatedItems };
      saveToStorage(updated);
      return updated;
    });
  };

  const deleteService = (id: number) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        services: prev.services.filter((s) => s.id !== id),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  // CRUD FAQs
  const addOrUpdateFaq = (faq: FAQItem) => {
    setConfig((prev) => {
      const exists = prev.faqs.some((f) => f.id === faq.id);
      const updatedItems = exists
        ? prev.faqs.map((f) => (f.id === faq.id ? faq : f))
        : [...prev.faqs, faq];
      const updated: SiteConfig = { ...prev, faqs: updatedItems };
      saveToStorage(updated);
      return updated;
    });
  };

  const deleteFaq = (id: string) => {
    setConfig((prev) => {
      const updated: SiteConfig = {
        ...prev,
        faqs: prev.faqs.filter((f) => f.id !== id),
      };
      saveToStorage(updated);
      return updated;
    });
  };

  return (
    <SiteConfigContext.Provider
      value={{
        config,
        updateConfig,
        resetConfig,
        toggleSection,
        addLead,
        updateLeadStatus,
        deleteLead,
        clearAllLeads,
        addOrUpdateCover,
        deleteCover,
        addOrUpdateTestimonial,
        deleteTestimonial,
        addOrUpdateBooktrailer,
        deleteBooktrailer,
        addOrUpdateService,
        deleteService,
        addOrUpdateFaq,
        deleteFaq,
      }}
    >
      {children}
    </SiteConfigContext.Provider>
  );
};

export const useSiteConfig = () => {
  const context = useContext(SiteConfigContext);
  if (!context) {
    throw new Error('useSiteConfig must be used within a SiteConfigProvider');
  }
  return context;
};
