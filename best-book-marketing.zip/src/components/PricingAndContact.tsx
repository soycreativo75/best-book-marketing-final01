import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Check, ShieldCheck, Sparkles, Send, Calendar, Clock, Star, ArrowRight } from 'lucide-react';
import { ThemeMode } from '../types';
import { useSiteConfig } from '../context/SiteConfigContext';

interface PricingAndContactProps {
  theme: ThemeMode;
}

export const PricingAndContact: React.FC<PricingAndContactProps> = ({ theme }) => {
  const { config, addLead } = useSiteConfig();
  const [formSubmitted, setFormSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    genero: 'No-Ficción / Negocios',
    estado: 'Manuscrito Terminado',
    mensaje: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addLead({
      source: 'contact_form',
      name: formData.nombre,
      email: formData.email,
      genre: formData.genero,
      manuscriptStatus: formData.estado,
      message: formData.mensaje,
    });
    setFormSubmitted(true);
  };

  const plans = [
    {
      name: config.planStarterTitle,
      badge: 'Ideal para Primerizos',
      price: `$${config.planStarterPrice.toLocaleString()}`,
      period: 'pago único',
      desc: 'Todo lo indispensable para publicar con calidad editorial profesional y evitar rechazos técnicos.',
      features: [
        'Diseño de Portada para eBook y Tapa Blanda',
        'Maquetación Editorial KDP (ePub & PDF de Imprenta)',
        'Optimización de Metadatos y 10 Categorías KDP',
        'Kit de 3 Mockups 3D Publicitarios',
        'Garantía de Aprobación 100% en Amazon',
      ],
      popular: false,
    },
    {
      name: config.planProTitle,
      badge: 'El Más Elegido',
      price: `$${config.planProPrice.toLocaleString()}`,
      period: 'pago único',
      desc: 'Nuestra solución insignia con Booktrailer 4K y estrategia de preventa para alcanzar el badge #1.',
      features: [
        'Todo lo del Pack Lanzamiento Esencial',
        'Booktrailer Cinematográfico 4K (9:16 y 16:9)',
        'Diseño de Contenido A+ (4 Módulos Premium)',
        'Estrategia de 30 Días para Equipo de Lanzamiento (ARC)',
        'Campaña de Amazon Ads guiada para el día de estreno',
        'Soporte prioritario 1 a 1 por WhatsApp con el Director',
      ],
      popular: true,
    },
    {
      name: config.planEliteTitle,
      badge: 'Para Líderes y Marcas',
      price: `$${config.planElitePrice.toLocaleString()}`,
      period: 'pago único',
      desc: 'Para empresarios y conferencistas que buscan usar su libro como la palanca maestra de su negocio.',
      features: [
        'Todo lo del Pack Bestseller Élite',
        'Pack de 2 Booktrailers (Ficción/Emocional y Pitch)',
        'Embudo de Captación de Lectores para tu Negocio',
        'Diseño de Ficha de Autor y Brand Story Completa',
        'Estrategia de Difusión en Prensa y Medios Digitales',
        'Garantía Contractual de Top 10 Bestseller',
      ],
      popular: false,
    },
  ];

  return (
    <>
      {/* Sección de Planes */}
      <section
        id="planes"
        className={`relative z-10 py-20 lg:py-28 border-t transition-colors ${
          theme === 'light'
            ? 'bg-slate-50/70 border-slate-200'
            : 'bg-[#080709] border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#080709] border border-[#D62828]/45 text-[#F5A623] text-xs font-gotham font-bold uppercase tracking-widest shadow-sm">
              <Sparkles className="w-3.5 h-3.5 text-[#D62828]" />
              Inversión Transparente
            </div>
            <h2 className={`font-gotham text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
              Planes Diseñados para Garantizar tu{' '}
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D62828] to-[#F5A623]">
                Retorno de Autor
              </span>
            </h2>
            <p className={`text-base ${theme === 'light' ? 'text-slate-600' : 'text-slate-300'}`}>
              Sin letra pequeña ni regalías compartidas: el 100% de las ganancias y derechos de tu obra te pertenecen para siempre.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
            {plans.map((plan, index) => (
              <div
                key={index}
                className={`relative rounded-3xl p-8 border flex flex-col justify-between transition-all duration-300 ${
                  plan.popular
                    ? 'border-[#D62828] ring-2 ring-[#D62828]/50 shadow-[0_0_45px_rgba(214,40,40,0.25)] scale-[1.02] bg-[#141118]'
                    : theme === 'light'
                    ? 'bg-white border-slate-200 shadow-lg'
                    : 'bg-[#141118]/80 border-white/10'
                } ${theme === 'light' && plan.popular ? 'bg-white ring-[#D62828]/30' : ''}`}
              >
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white font-gotham font-black text-xs uppercase tracking-wider shadow-md">
                    {plan.badge}
                  </div>
                )}

                <div>
                  <div className="mb-4">
                    <span className="text-xs font-gotham font-bold text-slate-400 uppercase tracking-wider block">
                      {plan.name}
                    </span>
                    <div className="flex items-baseline gap-2 mt-2">
                      <span className={`font-gotham text-4xl font-black ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                        {plan.price}
                      </span>
                      <span className="text-xs text-slate-400 font-mono">{plan.period}</span>
                    </div>
                    <p className="text-xs text-slate-400 mt-2 leading-relaxed">
                      {plan.desc}
                    </p>
                  </div>

                  <ul className="space-y-3 pt-6 border-t border-white/10 mb-8">
                    {plan.features.map((feat, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-3 text-xs">
                        <Check className="w-4 h-4 text-[#F5A623] shrink-0 mt-0.5" />
                        <span className={theme === 'light' ? 'text-slate-700' : 'text-slate-300'}>
                          {feat}
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>

                <a
                  href="#contacto"
                  className={`w-full py-3.5 rounded-xl font-gotham font-black text-xs uppercase tracking-wider text-center transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    plan.popular
                      ? 'bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white hover:brightness-110 shadow-[0_0_20px_rgba(214,40,40,0.4)]'
                      : theme === 'light'
                      ? 'bg-slate-100 hover:bg-slate-200 text-slate-800'
                      : 'bg-white/5 hover:bg-white/10 text-white border border-white/10'
                  }`}
                >
                  <span>Elegir {plan.name.split(' ')[1]}</span>
                  <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Sección de Contacto / Agendar Consulta */}
      <section
        id="contacto"
        className={`relative z-10 py-20 lg:py-28 border-t transition-colors ${
          theme === 'light'
            ? 'bg-white border-slate-200'
            : 'bg-[#080709] border-white/10'
        }`}
      >
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <div
            className={`rounded-3xl p-8 sm:p-12 border backdrop-blur-2xl shadow-2xl relative overflow-hidden ${
              theme === 'light'
                ? 'bg-slate-50 border-slate-200 shadow-slate-200'
                : 'bg-[#141118]/90 border-white/10 shadow-[0_0_50px_rgba(214,40,40,0.15)]'
            }`}
          >
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
              {/* Info y Propuesta de Valor */}
              <div className="lg:col-span-5 space-y-6">
                <div>
                  <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#080709] border border-[#D62828]/45 text-[#F5A623] text-xs font-gotham font-bold uppercase tracking-widest mb-3 shadow-sm">
                    <Calendar className="w-3.5 h-3.5 text-[#D62828]" />
                    Sesión Estratégica Gratuita
                  </div>
                  <h3 className={`font-gotham text-2xl sm:text-3xl font-black tracking-tight ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                    Analicemos el Potencial Comercial de tu Libro
                  </h3>
                  <p className={`text-xs sm:text-sm mt-2 leading-relaxed ${theme === 'light' ? 'text-slate-600' : 'text-slate-300'}`}>
                    Agenda una llamada de 20 minutos sin compromiso. Evaluaremos tu portada, género y estrategia de lanzamiento para diseñar tu hoja de ruta Bestseller.
                  </p>
                </div>

                <div className="space-y-3 pt-2">
                  <div className="flex items-center gap-3 text-xs text-slate-300">
                    <div className="w-7 h-7 rounded-lg bg-[#D62828]/20 flex items-center justify-center text-[#F5A623]">
                      <Clock className="w-4 h-4" />
                    </div>
                    <span className={theme === 'light' ? 'text-slate-700' : 'text-slate-300'}>
                      Respuesta garantizada en menos de 24 horas laborales
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-slate-300">
                    <div className="w-7 h-7 rounded-lg bg-[#D62828]/20 flex items-center justify-center text-[#F5A623]">
                      <ShieldCheck className="w-4 h-4" />
                    </div>
                    <span className={theme === 'light' ? 'text-slate-700' : 'text-slate-300'}>
                      Acuerdo de Confidencialidad (NDA) para proteger tu manuscrito
                    </span>
                  </div>
                </div>

                <div
                  className={`p-4 rounded-2xl border ${
                    theme === 'light'
                      ? 'bg-slate-100 border-slate-200 text-slate-700'
                      : 'bg-[#080709] border-white/10 text-slate-300'
                  }`}
                >
                  <p className="text-xs italic">
                    "Publicar en Amazon sin una estrategia editorial es como abrir un local en el desierto. Te ayudamos a colocarlo en la avenida principal."
                  </p>
                  <span className="text-[11px] font-gotham font-bold text-[#F5A623] mt-2 block">
                    — Equipo Best Book Marketing
                  </span>
                </div>
              </div>

              {/* Formulario */}
              <div className="lg:col-span-7">
                {formSubmitted ? (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="p-8 rounded-2xl bg-[#D62828]/10 border border-[#D62828] text-center space-y-4"
                  >
                    <div className="w-14 h-14 rounded-full bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white flex items-center justify-center mx-auto shadow-lg">
                      <Check className="w-8 h-8" />
                    </div>
                    <h4 className={`font-gotham text-2xl font-black ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
                      ¡Solicitud Recibida con Éxito!
                    </h4>
                    <p className={`text-xs sm:text-sm ${theme === 'light' ? 'text-slate-800 font-medium' : 'text-slate-300'}`}>
                      Uno de nuestros directores editoriales te contactará en tu correo <strong>{formData.email}</strong>. Tu mensaje ha sido registrado y enviado al buzón editorial (<strong>{config.notificationEmail}</strong>).
                    </p>
                    <button
                      onClick={() => setFormSubmitted(false)}
                      className={`px-6 py-2.5 rounded-xl text-xs font-gotham font-bold transition-colors cursor-pointer ${
                        theme === 'light'
                          ? 'bg-slate-900 text-white hover:bg-slate-800'
                          : 'bg-white/10 text-white hover:bg-white/20'
                      }`}
                    >
                      Enviar otra consulta
                    </button>
                  </motion.div>
                ) : (
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className={`block text-xs font-gotham font-bold mb-1.5 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                          Tu Nombre o Seudónimo:
                        </label>
                        <input
                          type="text"
                          required
                          value={formData.nombre}
                          onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                          placeholder="Ej. Miguel Ángel Reyes"
                          className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                            theme === 'light'
                              ? 'bg-slate-100 border-slate-300 text-slate-900 focus:bg-white placeholder:text-slate-400'
                              : 'bg-[#080709] border-white/10 text-white placeholder:text-slate-500'
                          }`}
                        />
                      </div>
                      <div>
                        <label className={`block text-xs font-gotham font-bold mb-1.5 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                          Correo Electrónico:
                        </label>
                        <input
                          type="email"
                          required
                          value={formData.email}
                          onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                          placeholder="autor@ejemplo.com"
                          className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                            theme === 'light'
                              ? 'bg-slate-100 border-slate-300 text-slate-900 focus:bg-white placeholder:text-slate-400'
                              : 'bg-[#080709] border-white/10 text-white placeholder:text-slate-500'
                          }`}
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className={`block text-xs font-gotham font-bold mb-1.5 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                          Género del Libro:
                        </label>
                        <select
                          value={formData.genero}
                          onChange={(e) => setFormData({ ...formData, genero: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                            theme === 'light'
                              ? 'bg-slate-100 border-slate-300 text-slate-900 focus:bg-white'
                              : 'bg-[#080709] border-white/10 text-white'
                          }`}
                        >
                          <option value="No-Ficción / Negocios">No-Ficción / Negocios</option>
                          <option value="Desarrollo Personal">Desarrollo Personal / Autoayuda</option>
                          <option value="Ficción / Novela">Ficción / Novela / Thriller</option>
                          <option value="Fantasía / Ciencia Ficción">Fantasía / Sci-Fi</option>
                          <option value="Poesía / Biografía">Poesía / Memorias</option>
                        </select>
                      </div>

                      <div>
                        <label className={`block text-xs font-gotham font-bold mb-1.5 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                          Estado del Manuscrito:
                        </label>
                        <select
                          value={formData.estado}
                          onChange={(e) => setFormData({ ...formData, estado: e.target.value })}
                          className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                            theme === 'light'
                              ? 'bg-slate-100 border-slate-300 text-slate-900 focus:bg-white'
                              : 'bg-[#080709] border-white/10 text-white'
                          }`}
                        >
                          <option value="Manuscrito Terminado">Manuscrito 100% Terminado</option>
                          <option value="En Corrección Final">En Corrección Final</option>
                          <option value="En Proceso de Escritura">En Proceso de Escritura</option>
                          <option value="Libro Ya Publicado para Relanzar">Libro Ya Publicado (Quiero Relanzar)</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <label className={`block text-xs font-gotham font-bold mb-1.5 ${theme === 'light' ? 'text-slate-700' : 'text-slate-300'}`}>
                        Detalles sobre tu Proyecto o Dudas:
                      </label>
                      <textarea
                        rows={3}
                        value={formData.mensaje}
                        onChange={(e) => setFormData({ ...formData, mensaje: e.target.value })}
                        placeholder="Cuéntanos brevemente de qué trata tu libro y tus metas de ventas..."
                        className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                          theme === 'light'
                            ? 'bg-slate-100 border-slate-300 text-slate-900 focus:bg-white placeholder:text-slate-400'
                            : 'bg-[#080709] border-white/10 text-white placeholder:text-slate-500'
                        }`}
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-4 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white font-gotham font-black text-xs uppercase tracking-wider hover:brightness-110 shadow-[0_0_25px_rgba(214,40,40,0.4)] transition-all flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Send className="w-4 h-4" />
                      <span>Solicitar Diagnóstico Editorial Gratuito</span>
                    </button>
                  </form>
                )}
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};
