import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Play, Film, Sparkles, Clock, Eye, Volume2, ArrowRight, CheckCircle2, Pause } from 'lucide-react';
import { BooktrailerItem, ThemeMode } from '../types';

interface BooktrailersGalleryProps {
  trailers: BooktrailerItem[];
  theme: ThemeMode;
}

export const BooktrailersGallery: React.FC<BooktrailersGalleryProps> = ({ trailers, theme }) => {
  const [selectedTrailer, setSelectedTrailer] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const currentTrailer = trailers[selectedTrailer];

  const handleSelectTrailer = (index: number) => {
    setSelectedTrailer(index);
    setIsPlaying(false);
  };

  return (
    <section
      id="booktrailers"
      className={`relative z-10 py-20 lg:py-28 border-t transition-colors ${
        theme === 'light'
          ? 'bg-white border-slate-200'
          : 'bg-[#080709] border-white/10'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Cabecera */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#080709] border border-[#D62828]/45 text-[#F5A623] text-xs font-gotham font-bold uppercase tracking-widest shadow-sm">
            <Film className="w-3.5 h-3.5 text-[#D62828]" />
            Producción Audiovisual Cinematográfica
          </div>
          <h2 className={`font-gotham text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight ${theme === 'light' ? 'text-slate-900' : 'text-white'}`}>
            Booktrailers que Convierten Espectadores en{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-[#D62828] to-[#F5A623]">
              Lectores Obsesivos
            </span>
          </h2>
          <p className={`text-base sm:text-lg ${theme === 'light' ? 'text-slate-600' : 'text-slate-300'}`}>
            Lanza tu libro con la misma emoción que un estreno cinematográfico. Producimos trailers en 4K con efectos visuales y sonido envolvente para tus anuncios en Meta, TikTok y YouTube.
          </p>
        </div>

        {/* Reproductor Principal Interactivo */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Lado Izquierdo: Pantalla de Reproducción de Video */}
          <div className="lg:col-span-8">
            <div
              className={`relative rounded-2xl overflow-hidden aspect-video border shadow-2xl group flex items-center justify-center ${
                theme === 'light' ? 'border-slate-300 bg-slate-900' : 'border-[#D62828]/40 bg-black shadow-[0_0_40px_rgba(214,40,40,0.25)]'
              }`}
            >
              {/* Imagen de fondo / Frame del video */}
              <img
                src={currentTrailer.thumbnail}
                alt={currentTrailer.title}
                className={`w-full h-full object-cover transition-all duration-700 ${
                  isPlaying ? 'scale-105 brightness-90 filter contrast-110' : 'brightness-75 filter contrast-105'
                }`}
              />

              {/* Degradado cinematográfico */}
              <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-transparent to-black/60 pointer-events-none" />

              {/* Efecto letterbox de cine */}
              <div className="absolute top-0 left-0 right-0 h-4 bg-black/80" />
              <div className="absolute bottom-0 left-0 right-0 h-4 bg-black/80" />

              {/* Botón Central de Play/Pause */}
              <button
                onClick={() => setIsPlaying(!isPlaying)}
                className="relative z-20 w-20 h-20 rounded-full bg-gradient-to-br from-[#D62828] to-[#b71c1c] text-white flex items-center justify-center shadow-[0_0_40px_rgba(214,40,40,0.8)] hover:scale-110 active:scale-95 transition-all cursor-pointer group"
                aria-label={isPlaying ? 'Pausar trailer' : 'Reproducir trailer'}
              >
                {isPlaying ? (
                  <Pause className="w-8 h-8 fill-current" />
                ) : (
                  <Play className="w-8 h-8 fill-current ml-1" />
                )}
              </button>

              {/* Información flotante sobre el video */}
              <div className="absolute bottom-6 left-6 right-6 z-20 flex justify-between items-end">
                <div className="space-y-1">
                  <span className="text-[10px] font-gotham font-black uppercase tracking-wider text-[#F5A623] px-2 py-0.5 rounded bg-black/70 border border-[#D62828]/40">
                    {currentTrailer.genre}
                  </span>
                  <h4 className="font-gotham text-xl sm:text-2xl font-black text-white drop-shadow-md">
                    {currentTrailer.title}
                  </h4>
                  <p className="text-xs text-slate-300 font-medium">{currentTrailer.duration} • Master 4K Ultra HD</p>
                </div>

                <div className="flex items-center gap-2 text-xs text-white bg-black/60 px-3 py-1.5 rounded-xl border border-white/10 backdrop-blur-md">
                  <Volume2 className="w-4 h-4 text-[#F5A623]" />
                  <span>5.1 Surround FX</span>
                </div>
              </div>

              {/* Indicador de reproducción */}
              {isPlaying && (
                <div className="absolute top-7 right-7 z-20 flex items-center gap-2 bg-red-600/90 text-white text-[10px] font-gotham font-black px-2.5 py-1 rounded-full uppercase tracking-wider animate-pulse">
                  <span className="w-2 h-2 rounded-full bg-white" />
                  Reproduciendo Trailer
                </div>
              )}
            </div>
          </div>

          {/* Lado Derecho: Lista de Selección de Trailers */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="font-gotham font-black text-sm uppercase tracking-wider text-slate-400 mb-2">
              Seleccionar Producción:
            </h3>

            {trailers.map((trailer, idx) => (
              <div
                key={trailer.id}
                onClick={() => handleSelectTrailer(idx)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer flex items-center gap-4 ${
                  selectedTrailer === idx
                    ? 'bg-[#141118] border-[#D62828] shadow-[0_0_20px_rgba(214,40,40,0.25)]'
                    : theme === 'light'
                    ? 'bg-slate-50 border-slate-200 hover:border-[#D62828]'
                    : 'bg-[#141118]/60 border-white/10 hover:border-[#D62828]/50'
                }`}
              >
                <div className="relative w-20 h-14 rounded-lg overflow-hidden flex-shrink-0">
                  <img src={trailer.thumbnail} alt={trailer.title} className="w-full h-full object-cover" />
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                    <Play className="w-4 h-4 text-white fill-current" />
                  </div>
                </div>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-gotham font-bold text-[#F5A623] truncate">
                      {trailer.genre}
                    </span>
                    <span className="text-[10px] text-slate-400 font-mono">{trailer.duration}</span>
                  </div>
                  <h4 className="font-gotham font-bold text-xs text-white truncate">{trailer.title}</h4>
                  <p className="text-[10px] text-slate-400 truncate">{trailer.videoPlaceholderTag}</p>
                </div>
              </div>
            ))}

            <div className="pt-4">
              <a
                href="#contacto"
                className="w-full py-3 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white font-gotham font-black text-xs uppercase tracking-wider hover:brightness-110 shadow-lg transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Solicitar Booktrailer para mi Libro</span>
                <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
