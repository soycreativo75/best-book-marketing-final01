import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import {
  Settings,
  Image as ImageIcon,
  Type,
  Phone,
  DollarSign,
  Save,
  RotateCcw,
  ArrowLeft,
  Upload,
  CheckCircle,
  Trash2,
  Lock,
  User,
  KeyRound,
  LogOut,
  AlertCircle,
  ToggleLeft,
  ToggleRight,
  Mail,
  Inbox,
  BookOpen,
  MessageSquare,
  Video,
  HelpCircle,
  Plus,
  ShieldCheck,
} from 'lucide-react';
import {
  ThemeMode,
  AppPage,
  SiteConfig,
  PortfolioCover,
  TestimonialItem,
  BooktrailerItem,
  ServiceItem,
  FAQItem,
  SectionsVisibility,
  LeadSubmission,
} from '../../types';
import { useSiteConfig, DEFAULT_SITE_CONFIG } from '../../context/SiteConfigContext';
import { BestBookLogo } from '../BestBookLogo';

interface AdminPanelPageProps {
  theme: ThemeMode;
  onNavigate: (page: AppPage) => void;
  onToggleTheme: () => void;
}

type AdminTab =
  | 'sections'
  | 'leads'
  | 'email_config'
  | 'texts'
  | 'covers'
  | 'testimonials'
  | 'booktrailers'
  | 'services'
  | 'faqs'
  | 'pricing'
  | 'logo';

export const AdminPanelPage: React.FC<AdminPanelPageProps> = ({
  theme,
  onNavigate,
}) => {
  const {
    config,
    updateConfig,
    resetConfig,
    toggleSection,
    updateLeadStatus,
    deleteLead,
    clearAllLeads,
    addOrUpdateCover,
    deleteCover,
    addOrUpdateTestimonial,
    deleteTestimonial,
    addOrUpdateBooktrailer,
    deleteBooktrailer,
    addOrUpdateService,
    deleteService,
    addOrUpdateFaq,
    deleteFaq,
  } = useSiteConfig();

  // Autenticación requerida: socabento / Joseluis75*
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    return sessionStorage.getItem('bbm_admin_authenticated') === 'true';
  });
  const [usernameInput, setUsernameInput] = useState('');
  const [passwordInput, setPasswordInput] = useState('');
  const [loginError, setLoginError] = useState('');

  const [formState, setFormState] = useState<SiteConfig>({ ...config });
  const [activeTab, setActiveTab] = useState<AdminTab>('sections');
  const [showToast, setShowToast] = useState(false);
  const [toastMessage, setToastMessage] = useState('');

  // Estados locales para nuevos elementos y edición
  const [editingCover, setEditingCover] = useState<PortfolioCover | null>(null);
  const [editingTestimonial, setEditingTestimonial] = useState<TestimonialItem | null>(null);
  const [editingBooktrailer, setEditingBooktrailer] = useState<BooktrailerItem | null>(null);
  const [editingService, setEditingService] = useState<ServiceItem | null>(null);
  const [editingFaq, setEditingFaq] = useState<FAQItem | null>(null);

  const whiteLogoInputRef = useRef<HTMLInputElement>(null);
  const blackLogoInputRef = useRef<HTMLInputElement>(null);

  const isLight = theme === 'light';

  // Sincronizar formState si config cambia
  useEffect(() => {
    setFormState({ ...config });
  }, [config]);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');

    const cleanUser = usernameInput.trim();
    const cleanPass = passwordInput.trim();

    if (cleanUser === 'socabento' && cleanPass === 'Joseluis75*') {
      setIsAuthenticated(true);
      sessionStorage.setItem('bbm_admin_authenticated', 'true');
      triggerToast('¡Acceso verificado! Bienvenido al panel de administración.');
    } else {
      setLoginError('Usuario o contraseña incorrectos. Por favor verifica tus credenciales.');
    }
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    sessionStorage.removeItem('bbm_admin_authenticated');
    onNavigate('home');
  };

  const handleChange = (field: keyof SiteConfig, value: any) => {
    setFormState((prev) => ({ ...prev, [field]: value }));
  };

  const handleSave = () => {
    updateConfig(formState);
    triggerToast('¡Configuración guardada con éxito en el sitio web!');
  };

  const handleReset = () => {
    if (
      window.confirm(
        '¿Deseas restaurar todos los textos, logotipo y configuración a sus valores originales?'
      )
    ) {
      resetConfig();
      setFormState({ ...DEFAULT_SITE_CONFIG });
      triggerToast('Valores restaurados a la configuración inicial.');
    }
  };

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 3500);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>, mode: 'white' | 'black') => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert('Por favor selecciona un archivo de imagen válido (PNG, SVG o JPG).');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (mode === 'white') {
        handleChange('logoWhiteUrl', result);
      } else {
        handleChange('logoBlackUrl', result);
      }
      triggerToast(
        mode === 'white'
          ? 'Logotipo para fondo oscuro cargado.'
          : 'Logotipo para fondo claro cargado.'
      );
    };
    reader.readAsDataURL(file);
  };

  // PANTALLA DE LOGIN
  if (!isAuthenticated) {
    return (
      <div
        className={`min-h-screen flex items-center justify-center p-4 transition-colors duration-300 ${
          isLight ? 'bg-[#F4F6F8] text-slate-900' : 'bg-[#080709] text-white'
        }`}
      >
        <div className="w-full max-w-md">
          <div className="flex items-center justify-between mb-8">
            <button
              onClick={() => onNavigate('home')}
              className={`flex items-center gap-2 text-xs font-gotham font-bold px-4 py-2 rounded-xl transition-all cursor-pointer ${
                isLight
                  ? 'bg-white hover:bg-slate-100 text-slate-800 border border-slate-200 shadow-sm'
                  : 'bg-[#141118] hover:bg-white/10 text-slate-200 border border-white/10'
              }`}
            >
              <ArrowLeft className="w-4 h-4 text-[#D62828]" />
              <span>Volver a la Web</span>
            </button>
            <BestBookLogo theme={theme} size="sm" />
          </div>

          <div
            className={`p-8 sm:p-10 rounded-3xl border shadow-2xl relative overflow-hidden ${
              isLight
                ? 'bg-white border-slate-300 text-slate-900 shadow-slate-200'
                : 'bg-[#141118] border-[#D62828]/40 text-white shadow-[0_0_50px_rgba(214,40,40,0.15)]'
            }`}
          >
            <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#D62828] to-[#F5A623] flex items-center justify-center mx-auto mb-6 text-white shadow-lg">
              <Lock className="w-7 h-7" />
            </div>

            <div className="text-center mb-8">
              <h2 className="font-gotham text-2xl font-black tracking-tight mb-2 text-[#D62828]">
                Panel de Administración
              </h2>
              <p className={`text-xs ${isLight ? 'text-slate-700 font-medium' : 'text-slate-400'}`}>
                Ingresa tus credenciales autorizadas para gestionar todo el contenido de Best Book Marketing.
              </p>
            </div>

            {loginError && (
              <div className="mb-6 p-4 rounded-xl bg-[#D62828]/15 border border-[#D62828] flex items-center gap-3 text-xs text-[#ff6b6b]">
                <AlertCircle className="w-5 h-5 flex-shrink-0 text-[#D62828]" />
                <span>{loginError}</span>
              </div>
            )}

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className={`block text-xs font-gotham font-bold mb-1.5 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                  Usuario Administrador:
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={usernameInput}
                    onChange={(e) => setUsernameInput(e.target.value)}
                    placeholder="socabento"
                    className={`w-full pl-10 pr-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white placeholder:text-slate-400 font-medium'
                        : 'bg-[#080709] border-white/10 text-white placeholder:text-slate-600'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className={`block text-xs font-gotham font-bold mb-1.5 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                  Contraseña de Seguridad:
                </label>
                <div className="relative">
                  <KeyRound className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={passwordInput}
                    onChange={(e) => setPasswordInput(e.target.value)}
                    placeholder="••••••••••••"
                    className={`w-full pl-10 pr-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] transition-all ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white placeholder:text-slate-400 font-medium'
                        : 'bg-[#080709] border-white/10 text-white placeholder:text-slate-600'
                    }`}
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-2 py-3.5 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white font-gotham font-black text-xs uppercase tracking-wider hover:brightness-110 shadow-[0_0_20px_rgba(214,40,40,0.35)] transition-all cursor-pointer"
              >
                Acceder al Panel
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  // PANEL PRINCIPAL
  return (
    <div
      className={`min-h-screen transition-colors duration-300 pb-20 ${
        isLight ? 'bg-[#F4F6F8] text-slate-900' : 'bg-[#080709] text-white'
      }`}
    >
      {/* Toast flotante de confirmación */}
      <AnimatePresence>
        {showToast && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-6 right-6 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-bold shadow-2xl border border-white/20"
          >
            <CheckCircle className="w-4 h-4 text-[#F5A623]" />
            <span>{toastMessage}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Barra superior de encabezado del panel */}
      <div
        className={`border-b sticky top-0 z-40 backdrop-blur-md transition-colors ${
          isLight ? 'bg-white/95 border-slate-200' : 'bg-[#080709]/95 border-white/10'
        }`}
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <button
              onClick={() => onNavigate('home')}
              className={`flex items-center gap-2 text-xs font-gotham font-bold px-3.5 py-2 rounded-xl transition-all cursor-pointer ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200'
                  : 'bg-[#141118] hover:bg-white/10 text-slate-200 border border-white/10'
              }`}
            >
              <ArrowLeft className="w-4 h-4 text-[#D62828]" />
              <span className="hidden sm:inline">Ver Sitio Web</span>
            </button>

            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse" />
              <span className="font-gotham font-black text-sm tracking-tight">
                Panel Administrador Total
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              onClick={handleReset}
              className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-gotham font-bold transition-all cursor-pointer ${
                isLight
                  ? 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                  : 'bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white'
              }`}
              title="Restaurar a valores predeterminados"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden md:inline">Restaurar Todo</span>
            </button>

            <button
              onClick={handleSave}
              className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-black hover:brightness-110 shadow-[0_0_15px_rgba(214,40,40,0.4)] transition-all cursor-pointer"
            >
              <Save className="w-3.5 h-3.5" />
              <span>Guardar Cambios</span>
            </button>

            <button
              onClick={handleLogout}
              className={`p-2 rounded-xl transition-colors cursor-pointer ${
                isLight ? 'bg-slate-100 hover:bg-rose-50 text-rose-600' : 'bg-white/5 hover:bg-white/10 text-rose-400'
              }`}
              title="Cerrar sesión"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8">
        {/* Banner de Correo Configurado */}
        <div
          className={`p-4 rounded-2xl border mb-6 flex flex-wrap items-center justify-between gap-4 ${
            isLight
              ? 'bg-amber-50 border-amber-300 text-slate-900'
              : 'bg-[#141118] border-[#D62828]/40 text-white'
          }`}
        >
          <div className="flex items-center gap-3">
            <Mail className="w-5 h-5 text-[#D62828] flex-shrink-0" />
            <div className="text-xs">
              <span className="font-gotham font-bold block">
                Buzón receptor activo para formularios y citas:
              </span>
              <span className="font-mono text-xs font-bold text-[#D62828]">
                {formState.notificationEmail || 'soycreativo2023@gmail.com'}
              </span>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('email_config')}
            className="text-xs font-gotham font-bold text-[#D62828] underline hover:brightness-125 cursor-pointer"
          >
            Modificar correo receptor
          </button>
        </div>

        {/* Pestañas de Navegación del Panel */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-4 mb-8 scrollbar-none border-b border-white/10">
          {[
            { id: 'sections', label: 'Apagar Secciones', icon: ToggleRight },
            { id: 'leads', label: `Buzón Leads (${config.leadsInbox?.length || 0})`, icon: Inbox },
            { id: 'email_config', label: 'Correo & Contacto', icon: Mail },
            { id: 'texts', label: 'Textos & Hero', icon: Type },
            { id: 'covers', label: `Portadas (${config.portfolioCovers?.length || 0})`, icon: BookOpen },
            { id: 'testimonials', label: `Testimonios (${config.testimonials?.length || 0})`, icon: MessageSquare },
            { id: 'booktrailers', label: `Booktrailers (${config.booktrailers?.length || 0})`, icon: Video },
            { id: 'services', label: `Servicios (${config.services?.length || 0})`, icon: Settings },
            { id: 'faqs', label: `Preguntas FAQ (${config.faqs?.length || 0})`, icon: HelpCircle },
            { id: 'pricing', label: 'Planes & Precios', icon: DollarSign },
            { id: 'logo', label: 'Logotipo', icon: ImageIcon },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as AdminTab)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-gotham font-bold whitespace-nowrap transition-all cursor-pointer ${
                  isActive
                    ? 'bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white shadow-[0_0_15px_rgba(214,40,40,0.35)]'
                    : isLight
                    ? 'bg-white text-slate-800 hover:bg-slate-100 border border-slate-300 font-semibold'
                    : 'bg-[#141118] text-slate-400 hover:text-white border border-white/10'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* CONTENIDO DE CADA PESTAÑA */}

        {/* 1. SECCIONES ACTIVAS / APAGADAS */}
        {activeTab === 'sections' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Interruptor de Secciones del Sitio Web
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Enciende o apaga cualquier componente de la página de inicio con un solo clic en tiempo real.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {[
                { key: 'hero', title: 'Hero Principal & Libro 3D', desc: 'Encabezado con título persuasivo, 3D interactivo y estadísticas.' },
                { key: 'portfolioCovers', title: 'Carrusel de Portadas', desc: 'Muestra interactiva de portadas de libros en formato slider.' },
                { key: 'services', title: 'Servicios Editoriales 360', desc: 'Cuadrícula de maquetación, diseño, marketing y asesoría.' },
                { key: 'booktrailers', title: 'Galería de Booktrailers 4K', desc: 'Videos promocionales cinematográficos de libros.' },
                { key: 'royaltyCalculator', title: 'Calculadora de Regalías', desc: 'Simulador interactivo de ingresos en Amazon KDP.' },
                { key: 'testimonials', title: 'Testimonios de Autores', desc: 'Reseñas, casos de éxito y badge de verificación de ventas.' },
                { key: 'pricing', title: 'Tabla de Planes y Precios', desc: 'Tarjetas con los 3 paquetes editoriales (Starter, Pro, Elite).' },
                { key: 'contact', title: 'Formulario de Diagnóstico', desc: 'Formulario de contacto para solicitar propuesta de lanzamiento.' },
                { key: 'footer', title: 'Pie de Página (Footer)', desc: 'Enlaces legales, redes sociales, horarios y botón admin discreto.' },
              ].map((item) => {
                const isEnabled = formState.sectionsVisibility[item.key as keyof SectionsVisibility];
                return (
                  <div
                    key={item.key}
                    className={`p-5 rounded-2xl border transition-all flex flex-col justify-between ${
                      isEnabled
                        ? isLight
                          ? 'bg-white border-emerald-500/50 shadow-sm'
                          : 'bg-[#141118] border-emerald-500/40'
                        : isLight
                        ? 'bg-slate-100 border-slate-300 opacity-60'
                        : 'bg-[#141118]/40 border-white/5 opacity-50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <h3 className={`font-gotham font-black text-sm ${isEnabled ? 'text-[#D62828]' : 'text-slate-500'}`}>
                          {item.title}
                        </h3>
                        <span
                          className={`text-[10px] font-gotham font-bold px-2 py-0.5 rounded-full ${
                            isEnabled
                              ? 'bg-emerald-500/20 text-emerald-600 border border-emerald-500/30'
                              : 'bg-rose-500/20 text-rose-500 border border-rose-500/30'
                          }`}
                        >
                          {isEnabled ? 'ACTIVA' : 'APAGADA'}
                        </span>
                      </div>
                      <p className={`text-xs ${isLight ? 'text-slate-800' : 'text-slate-400'} leading-relaxed mb-4`}>
                        {item.desc}
                      </p>
                    </div>

                    <button
                      onClick={() => {
                        const updated = {
                          ...formState.sectionsVisibility,
                          [item.key]: !isEnabled,
                        };
                        handleChange('sectionsVisibility', updated);
                        toggleSection(item.key as keyof SectionsVisibility);
                        triggerToast(
                          `Sección "${item.title}" ${!isEnabled ? 'activada' : 'desactivada'}.`
                        );
                      }}
                      className={`w-full py-2.5 rounded-xl text-xs font-gotham font-bold flex items-center justify-center gap-2 transition-all cursor-pointer ${
                        isEnabled
                          ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-md'
                          : isLight
                          ? 'bg-slate-300 hover:bg-slate-400 text-slate-800'
                          : 'bg-white/10 hover:bg-white/20 text-white'
                      }`}
                    >
                      {isEnabled ? <ToggleRight className="w-4 h-4" /> : <ToggleLeft className="w-4 h-4" />}
                      <span>{isEnabled ? 'Apagar esta Sección' : 'Encender Sección'}</span>
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* 2. BANDEJA DE LEADS / FORMULARIOS */}
        {activeTab === 'leads' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Bandeja de Entrada de Solicitudes y Formularios
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Registro de cada autor que completó el formulario de contacto o agendó una asesoría. Se envían a: <strong>{config.notificationEmail}</strong>.
                </p>
              </div>

              {config.leadsInbox && config.leadsInbox.length > 0 && (
                <button
                  onClick={() => {
                    if (window.confirm('¿Deseas vaciar todos los registros del buzón?')) {
                      clearAllLeads();
                      triggerToast('Buzón de leads vaciado.');
                    }
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 text-xs font-gotham font-bold border border-rose-500/20 flex items-center gap-1.5 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>Vaciar Registros</span>
                </button>
              )}
            </div>

            {(!config.leadsInbox || config.leadsInbox.length === 0) ? (
              <div className={`text-center py-16 rounded-3xl border ${isLight ? 'bg-white border-slate-200' : 'bg-[#141118] border-white/10'}`}>
                <Inbox className="w-12 h-12 text-slate-400 mx-auto mb-3" />
                <h3 className="font-gotham font-bold text-base mb-1">Buzón Vacío</h3>
                <p className={`text-xs ${isLight ? 'text-slate-600' : 'text-slate-400'} max-w-sm mx-auto`}>
                  Cuando los visitantes envíen formularios desde la página web, se registrarán aquí instantáneamente con todos sus datos.
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {config.leadsInbox.map((lead) => (
                  <div
                    key={lead.id}
                    className={`p-5 rounded-2xl border transition-all ${
                      isLight
                        ? 'bg-white border-slate-200 shadow-sm'
                        : 'bg-[#141118] border-white/10'
                    }`}
                  >
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2">
                        <span className="font-gotham font-black text-sm text-[#D62828]">
                          {lead.name}
                        </span>
                        <span className="text-[11px] px-2 py-0.5 rounded-full bg-[#D62828]/10 text-[#D62828] font-gotham font-bold">
                          {lead.source === 'contact_form' ? 'Formulario Diagnóstico' : 'Modal Asesoría'}
                        </span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded-full font-gotham font-bold ${
                            lead.status === 'new'
                              ? 'bg-amber-500/20 text-amber-500'
                              : lead.status === 'contacted'
                              ? 'bg-blue-500/20 text-blue-500'
                              : 'bg-emerald-500/20 text-emerald-500'
                          }`}
                        >
                          {lead.status === 'new' ? 'NUEVO' : lead.status === 'contacted' ? 'CONTACTADO' : 'COMPLETADO'}
                        </span>
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {new Date(lead.createdAt).toLocaleString()}
                      </span>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs mb-3">
                      <div>
                        <span className="text-slate-400 block">Correo:</span>
                        <a href={`mailto:${lead.email}`} className="font-medium text-[#D62828] hover:underline">
                          {lead.email}
                        </a>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Teléfono / WhatsApp:</span>
                        <span className="font-medium">{lead.phone || 'No especificado'}</span>
                      </div>
                      <div>
                        <span className="text-slate-400 block">Género / Estado:</span>
                        <span className="font-medium">
                          {lead.genre || '-'} | {lead.manuscriptStatus || '-'}
                        </span>
                      </div>
                    </div>

                    {lead.message && (
                      <div className={`p-3 rounded-xl text-xs mb-3 ${isLight ? 'bg-slate-100 text-slate-800' : 'bg-white/5 text-slate-300'}`}>
                        <strong>Mensaje:</strong> {lead.message}
                      </div>
                    )}

                    <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-white/5">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => updateLeadStatus(lead.id, 'contacted')}
                          className="px-2.5 py-1 rounded-lg bg-blue-500/10 text-blue-500 hover:bg-blue-500/20 text-[11px] font-gotham font-bold cursor-pointer"
                        >
                          Marcar Contactado
                        </button>
                        <button
                          onClick={() => updateLeadStatus(lead.id, 'completed')}
                          className="px-2.5 py-1 rounded-lg bg-emerald-500/10 text-emerald-500 hover:bg-emerald-500/20 text-[11px] font-gotham font-bold cursor-pointer"
                        >
                          Marcar Completado
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <a
                          href={`mailto:${lead.email}?subject=Respuesta Best Book Marketing&body=Hola ${lead.name},`}
                          className="px-3 py-1 rounded-lg bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-[11px] font-gotham font-bold flex items-center gap-1 cursor-pointer"
                        >
                          <Mail className="w-3 h-3" />
                          <span>Responder por Correo</span>
                        </a>
                        <button
                          onClick={() => deleteLead(lead.id)}
                          className="p-1.5 rounded-lg text-rose-400 hover:bg-rose-500/10 cursor-pointer"
                          title="Eliminar lead"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* 3. CORREO Y DATOS DE CONTACTO */}
        {activeTab === 'email_config' && (
          <div className="space-y-6">
            <div>
              <h2 className="font-gotham text-xl font-black text-[#D62828]">
                Canales de Recepción y Datos de Contacto
              </h2>
              <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                Configura el correo al que deben llegar todos los formularios y botones de la página web.
              </p>
            </div>

            <div className={`p-6 sm:p-8 rounded-3xl border space-y-6 ${isLight ? 'bg-white border-slate-300' : 'bg-[#141118] border-white/10'}`}>
              <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <span className="font-gotham font-bold text-amber-500 block">
                    Dirección de Notificación Principal
                  </span>
                  <p className={isLight ? 'text-slate-800' : 'text-slate-300'}>
                    A este correo se envían automáticamente las alertas de nuevos autores interesados y solicitudes de diagnóstico.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Correo Electrónico Receptor (Notificaciones):
                  </label>
                  <input
                    type="email"
                    value={formState.notificationEmail || ''}
                    onChange={(e) => handleChange('notificationEmail', e.target.value)}
                    placeholder="soycreativo2023@gmail.com"
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] font-mono ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white font-bold'
                        : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Predeterminado: soycreativo2023@gmail.com
                  </span>
                </div>

                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Correo de Contacto Público (Visible en Footer):
                  </label>
                  <input
                    type="email"
                    value={formState.contactEmail}
                    onChange={(e) => handleChange('contactEmail', e.target.value)}
                    placeholder="soycreativo2023@gmail.com"
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white font-medium'
                        : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Número de WhatsApp (con prefijo internacional):
                  </label>
                  <input
                    type="text"
                    value={formState.whatsappNumber}
                    onChange={(e) => handleChange('whatsappNumber', e.target.value)}
                    placeholder="+34612345678"
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white font-medium'
                        : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>

                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Teléfono de Oficina:
                  </label>
                  <input
                    type="text"
                    value={formState.contactPhone}
                    onChange={(e) => handleChange('contactPhone', e.target.value)}
                    placeholder="+34 910 000 000"
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white font-medium'
                        : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Dirección Física / Sede:
                  </label>
                  <input
                    type="text"
                    value={formState.officeAddress}
                    onChange={(e) => handleChange('officeAddress', e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white font-medium'
                        : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Horario de Atención:
                  </label>
                  <input
                    type="text"
                    value={formState.businessHours}
                    onChange={(e) => handleChange('businessHours', e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight
                        ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white font-medium'
                        : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 4. TEXTOS Y HERO */}
        {activeTab === 'texts' && (
          <div className="space-y-6">
            <div>
              <h2 className="font-gotham text-xl font-black text-[#D62828]">
                Textos del Hero Principal y Estadísticas
              </h2>
              <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                Personaliza la propuesta de valor inicial que ven los autores al entrar a la página.
              </p>
            </div>

            <div className={`p-6 sm:p-8 rounded-3xl border space-y-6 ${isLight ? 'bg-white border-slate-300' : 'bg-[#141118] border-white/10'}`}>
              <div>
                <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                  Badge Superior de Autoridad:
                </label>
                <input
                  type="text"
                  value={formState.heroBadge}
                  onChange={(e) => handleChange('heroBadge', e.target.value)}
                  className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                    isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                  }`}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Título Línea 1 (Texto Blanco):
                  </label>
                  <input
                    type="text"
                    value={formState.heroTitleLine1}
                    onChange={(e) => handleChange('heroTitleLine1', e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>
                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Título Destacado (Gradiente Rojo/Dorado):
                  </label>
                  <input
                    type="text"
                    value={formState.heroTitleHighlight}
                    onChange={(e) => handleChange('heroTitleHighlight', e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>
              </div>

              <div>
                <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                  Subtítulo Explicativo de Conversión:
                </label>
                <textarea
                  rows={3}
                  value={formState.heroSubtitle}
                  onChange={(e) => handleChange('heroSubtitle', e.target.value)}
                  className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                    isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                  }`}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Texto del Botón CTA Principal:
                  </label>
                  <input
                    type="text"
                    value={formState.heroCtaText}
                    onChange={(e) => handleChange('heroCtaText', e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>
                <div>
                  <label className={`block text-xs font-gotham font-bold mb-2 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                    Texto del Botón Secundario (Calculadora):
                  </label>
                  <input
                    type="text"
                    value={formState.heroSecondaryCtaText}
                    onChange={(e) => handleChange('heroSecondaryCtaText', e.target.value)}
                    className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] ${
                      isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                    }`}
                  />
                </div>
              </div>

              {/* Estadísticas */}
              <div className="pt-4 border-t border-white/10">
                <h3 className="font-gotham font-bold text-sm text-[#D62828] mb-4">
                  Métricas de Conversión del Hero
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <div>
                    <label className={`block text-xs font-gotham font-bold mb-1.5 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                      Libros Top #1 Bestseller:
                    </label>
                    <input
                      type="text"
                      value={formState.statsTopBooks}
                      onChange={(e) => handleChange('statsTopBooks', e.target.value)}
                      placeholder="+180"
                      className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] font-bold ${
                        isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-xs font-gotham font-bold mb-1.5 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                      Regalías de Autor:
                    </label>
                    <input
                      type="text"
                      value={formState.statsRoyalties}
                      onChange={(e) => handleChange('statsRoyalties', e.target.value)}
                      placeholder="100%"
                      className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] font-bold ${
                        isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                      }`}
                    />
                  </div>
                  <div>
                    <label className={`block text-xs font-gotham font-bold mb-1.5 ${isLight ? 'text-slate-900' : 'text-slate-300'}`}>
                      Calificación Promedio:
                    </label>
                    <input
                      type="text"
                      value={formState.statsRating}
                      onChange={(e) => handleChange('statsRating', e.target.value)}
                      placeholder="4.9 / 5"
                      className={`w-full px-4 py-3 rounded-xl border text-xs focus:outline-none focus:border-[#D62828] font-bold ${
                        isLight ? 'bg-slate-50 border-slate-300 text-slate-900 focus:bg-white' : 'bg-[#080709] border-white/10 text-white'
                      }`}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 5. GESTOR DE PORTADAS (CARRUSEL DE LIBROS) */}
        {activeTab === 'covers' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Carrusel de Libros y Portadas Bestseller
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Añade, edita o elimina las portadas que se exhiben en el carrusel de la página de inicio.
                </p>
              </div>

              <button
                onClick={() =>
                  setEditingCover({
                    id: Date.now(),
                    title: 'Nuevo Libro Bestseller',
                    genre: 'Negocios',
                    sales: '+2,500 Copias',
                    imageUrl:
                      'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&w=800&q=80',
                    bgGradient: 'from-amber-950 via-slate-900 to-black',
                    accentColor: '#D62828',
                    bestsellerRank: 'Top #1 Bestseller',
                  })
                }
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Añadir Nueva Portada</span>
              </button>
            </div>

            {/* Formulario para editar portada */}
            {editingCover && (
              <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-300 shadow-lg' : 'bg-[#141118] border-[#D62828]/50 shadow-xl'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828] mb-4">
                  {config.portfolioCovers.some((c) => c.id === editingCover.id) ? 'Editar Portada' : 'Nueva Portada'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mb-4">
                  <div>
                    <label className="block font-gotham font-bold mb-1">Título del Libro:</label>
                    <input
                      type="text"
                      value={editingCover.title}
                      onChange={(e) => setEditingCover({ ...editingCover, title: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Género:</label>
                    <input
                      type="text"
                      value={editingCover.genre}
                      onChange={(e) => setEditingCover({ ...editingCover, genre: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Récord / Ventas (ej. +2,500 Copias):</label>
                    <input
                      type="text"
                      value={editingCover.sales}
                      onChange={(e) => setEditingCover({ ...editingCover, sales: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Badge (ej. Top #1 Bestseller):</label>
                    <input
                      type="text"
                      value={editingCover.bestsellerRank}
                      onChange={(e) => setEditingCover({ ...editingCover, bestsellerRank: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">URL de la Imagen de Portada:</label>
                    <input
                      type="text"
                      value={editingCover.imageUrl || ''}
                      onChange={(e) => setEditingCover({ ...editingCover, imageUrl: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingCover(null)}
                    className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-white/10 text-xs font-gotham font-bold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => {
                      addOrUpdateCover(editingCover);
                      setEditingCover(null);
                      triggerToast('Portada guardada en el carrusel.');
                    }}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-black cursor-pointer"
                  >
                    Guardar Portada
                  </button>
                </div>
              </div>
            )}

            {/* Listado de portadas */}
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {config.portfolioCovers.map((cover) => (
                <div
                  key={cover.id}
                  className={`rounded-2xl border overflow-hidden flex flex-col justify-between ${
                    isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141118] border-white/10'
                  }`}
                >
                  <div className="aspect-[2/3] w-full overflow-hidden bg-black/40 relative">
                    {cover.imageUrl ? (
                      <img
                        src={cover.imageUrl}
                        alt={cover.title}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center p-4 text-center text-xs text-slate-400 font-gotham font-bold">
                        {cover.title}
                      </div>
                    )}
                    <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-[#D62828] text-white text-[10px] font-gotham font-bold">
                      {cover.bestsellerRank}
                    </div>
                  </div>
                  <div className="p-3">
                    <h4 className="font-gotham font-bold text-xs truncate mb-0.5">{cover.title}</h4>
                    <p className="text-[11px] text-slate-400 truncate">{cover.genre} • {cover.sales}</p>
                    <div className="flex items-center justify-between gap-2 mt-3 pt-2 border-t border-white/5">
                      <button
                        onClick={() => setEditingCover(cover)}
                        className="text-[11px] font-gotham font-bold text-[#D62828] hover:underline cursor-pointer"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`¿Eliminar la portada "${cover.title}"?`)) {
                            deleteCover(cover.id);
                            triggerToast('Portada eliminada.');
                          }
                        }}
                        className="text-[11px] text-rose-500 hover:underline cursor-pointer"
                      >
                        Eliminar
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 6. GESTOR DE TESTIMONIOS */}
        {activeTab === 'testimonials' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Testimonios de Clientes y Autores
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Gestiona las experiencias, reseñas y sellos de Bestseller que aparecen en la prueba social.
                </p>
              </div>

              <button
                onClick={() =>
                  setEditingTestimonial({
                    id: Date.now(),
                    name: 'Nuevo Autor',
                    role: 'Empresario & Autor',
                    book: 'Título de su Libro',
                    metric: '#1 en Ventas Amazon',
                    copies: '+1,500 Copias',
                    rating: 5,
                    quote:
                      'La maquetación y la portada superaron todas mis expectativas. En 48 horas estábamos en el Top 10.',
                    avatar:
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
                  })
                }
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Añadir Testimonio</span>
              </button>
            </div>

            {editingTestimonial && (
              <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-300 shadow-lg' : 'bg-[#141118] border-[#D62828]/50 shadow-xl'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828] mb-4">
                  {config.testimonials.some((t) => t.id === editingTestimonial.id) ? 'Editar Testimonio' : 'Nuevo Testimonio'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mb-4">
                  <div>
                    <label className="block font-gotham font-bold mb-1">Nombre del Autor:</label>
                    <input
                      type="text"
                      value={editingTestimonial.name}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, name: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Rol / Profesión:</label>
                    <input
                      type="text"
                      value={editingTestimonial.role}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, role: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Título del Libro:</label>
                    <input
                      type="text"
                      value={editingTestimonial.book}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, book: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Métrica / Badge:</label>
                    <input
                      type="text"
                      value={editingTestimonial.metric}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, metric: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">Cita / Testimonio:</label>
                    <textarea
                      rows={2}
                      value={editingTestimonial.quote}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, quote: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">URL de Foto / Avatar:</label>
                    <input
                      type="text"
                      value={editingTestimonial.avatar}
                      onChange={(e) => setEditingTestimonial({ ...editingTestimonial, avatar: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingTestimonial(null)}
                    className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-white/10 text-xs font-gotham font-bold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => {
                      addOrUpdateTestimonial(editingTestimonial);
                      setEditingTestimonial(null);
                      triggerToast('Testimonio guardado.');
                    }}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-black cursor-pointer"
                  >
                    Guardar Testimonio
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {config.testimonials.map((t) => (
                <div
                  key={t.id}
                  className={`p-5 rounded-2xl border flex flex-col justify-between ${
                    isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141118] border-white/10'
                  }`}
                >
                  <div>
                    <div className="flex items-center gap-3 mb-3">
                      <img
                        src={t.avatar}
                        alt={t.name}
                        className="w-10 h-10 rounded-full object-cover border border-[#D62828]/40"
                        referrerPolicy="no-referrer"
                      />
                      <div>
                        <h4 className="font-gotham font-bold text-xs leading-tight">{t.name}</h4>
                        <span className="text-[11px] text-slate-400">{t.role}</span>
                      </div>
                    </div>
                    <div className="text-[11px] font-gotham font-bold text-[#D62828] mb-1">
                      {t.book} • {t.metric}
                    </div>
                    <p className={`text-xs ${isLight ? 'text-slate-800' : 'text-slate-300'} italic leading-relaxed mb-3`}>
                      "{t.quote}"
                    </p>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs">
                    <button
                      onClick={() => setEditingTestimonial(t)}
                      className="font-gotham font-bold text-[#D62828] hover:underline cursor-pointer"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`¿Eliminar el testimonio de "${t.name}"?`)) {
                          deleteTestimonial(t.id);
                          triggerToast('Testimonio eliminado.');
                        }
                      }}
                      className="text-rose-500 hover:underline cursor-pointer"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 7. GESTOR DE BOOKTRAILERS */}
        {activeTab === 'booktrailers' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Booktrailers Cinematográficos 4K
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Administra los trailers de libros, duraciones y previews de video.
                </p>
              </div>

              <button
                onClick={() =>
                  setEditingBooktrailer({
                    id: Date.now(),
                    title: 'Trailer Cinematográfico',
                    genre: 'Ficción / Thriller',
                    duration: '0:45',
                    views: '12.4K',
                    thumbnail:
                      'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=800&q=80',
                    videoPlaceholderTag: 'Teaser 4K',
                    directorNote: 'Producido para conversión en redes',
                    synopsis: 'Un teaser que eleva la tasa de conversión en redes.',
                  })
                }
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Añadir Booktrailer</span>
              </button>
            </div>

            {editingBooktrailer && (
              <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-300 shadow-lg' : 'bg-[#141118] border-[#D62828]/50 shadow-xl'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828] mb-4">
                  {config.booktrailers.some((b) => b.id === editingBooktrailer.id) ? 'Editar Trailer' : 'Nuevo Trailer'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mb-4">
                  <div>
                    <label className="block font-gotham font-bold mb-1">Título del Proyecto:</label>
                    <input
                      type="text"
                      value={editingBooktrailer.title}
                      onChange={(e) => setEditingBooktrailer({ ...editingBooktrailer, title: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Género:</label>
                    <input
                      type="text"
                      value={editingBooktrailer.genre}
                      onChange={(e) => setEditingBooktrailer({ ...editingBooktrailer, genre: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Duración (ej. 0:45):</label>
                    <input
                      type="text"
                      value={editingBooktrailer.duration}
                      onChange={(e) => setEditingBooktrailer({ ...editingBooktrailer, duration: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Tag / Formato:</label>
                    <input
                      type="text"
                      value={editingBooktrailer.videoPlaceholderTag}
                      onChange={(e) => setEditingBooktrailer({ ...editingBooktrailer, videoPlaceholderTag: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">URL de Thumbnail (Miniatura):</label>
                    <input
                      type="text"
                      value={editingBooktrailer.thumbnail}
                      onChange={(e) => setEditingBooktrailer({ ...editingBooktrailer, thumbnail: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 font-mono text-xs"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingBooktrailer(null)}
                    className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-white/10 text-xs font-gotham font-bold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => {
                      addOrUpdateBooktrailer(editingBooktrailer);
                      setEditingBooktrailer(null);
                      triggerToast('Booktrailer guardado.');
                    }}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-black cursor-pointer"
                  >
                    Guardar Booktrailer
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
              {config.booktrailers.map((b) => (
                <div
                  key={b.id}
                  className={`rounded-2xl border overflow-hidden flex flex-col justify-between ${
                    isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141118] border-white/10'
                  }`}
                >
                  <div className="aspect-video w-full overflow-hidden bg-black relative">
                    <img
                      src={b.thumbnail}
                      alt={b.title}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute bottom-2 right-2 px-2 py-0.5 rounded bg-black/80 text-white text-[10px] font-mono">
                      {b.duration}
                    </div>
                  </div>
                  <div className="p-4">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-gotham font-bold text-xs">{b.title}</h4>
                      <span className="text-[10px] text-[#D62828] font-gotham font-bold">{b.videoPlaceholderTag}</span>
                    </div>
                    <p className="text-[11px] text-slate-400 mb-3">{b.synopsis}</p>
                    <div className="flex items-center justify-between pt-2 border-t border-white/5 text-xs">
                      <button
                        onClick={() => setEditingBooktrailer(b)}
                        className="font-gotham font-bold text-[#D62828] hover:underline cursor-pointer"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`¿Eliminar booktrailer "${b.title}"?`)) {
                            deleteBooktrailer(b.id);
                            triggerToast('Booktrailer eliminado.');
                          }
                        }}
                        className="text-rose-500 hover:underline cursor-pointer"
                      >
                        Eliminar
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 8. GESTOR DE SERVICIOS EDITORIALES */}
        {activeTab === 'services' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Servicios Editoriales 360
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Personaliza los títulos, descripciones y características de cada servicio ofrecido.
                </p>
              </div>

              <button
                onClick={() =>
                  setEditingService({
                    id: Date.now(),
                    title: 'Nuevo Servicio Editorial',
                    tagline: 'Solución Integral',
                    iconName: 'BookOpen',
                    desc: 'Descripción detallada de la solución para autores.',
                    features: ['Entrega en alta resolución', 'Revisión técnica', 'Soporte prioritario'],
                    deliverables: 'Archivos listos para subir',
                  })
                }
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Añadir Servicio</span>
              </button>
            </div>

            {editingService && (
              <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-300 shadow-lg' : 'bg-[#141118] border-[#D62828]/50 shadow-xl'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828] mb-4">
                  {config.services.some((s) => s.id === editingService.id) ? 'Editar Servicio' : 'Nuevo Servicio'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mb-4">
                  <div>
                    <label className="block font-gotham font-bold mb-1">Título del Servicio:</label>
                    <input
                      type="text"
                      value={editingService.title}
                      onChange={(e) => setEditingService({ ...editingService, title: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Subtítulo / Tagline:</label>
                    <input
                      type="text"
                      value={editingService.tagline}
                      onChange={(e) => setEditingService({ ...editingService, tagline: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">Descripción:</label>
                    <textarea
                      rows={2}
                      value={editingService.desc}
                      onChange={(e) => setEditingService({ ...editingService, desc: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">Entregables Clave:</label>
                    <input
                      type="text"
                      value={editingService.deliverables}
                      onChange={(e) => setEditingService({ ...editingService, deliverables: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingService(null)}
                    className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-white/10 text-xs font-gotham font-bold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => {
                      addOrUpdateService(editingService);
                      setEditingService(null);
                      triggerToast('Servicio editorial guardado.');
                    }}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-black cursor-pointer"
                  >
                    Guardar Servicio
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {config.services.map((s) => (
                <div
                  key={s.id}
                  className={`p-5 rounded-2xl border flex flex-col justify-between ${
                    isLight ? 'bg-white border-slate-200 shadow-sm' : 'bg-[#141118] border-white/10'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-gotham font-bold px-2 py-0.5 rounded-full bg-[#D62828]/10 text-[#D62828]">
                        {s.tagline}
                      </span>
                    </div>
                    <h4 className="font-gotham font-black text-sm mb-1 text-[#D62828]">{s.title}</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-800' : 'text-slate-300'} leading-relaxed mb-3`}>
                      {s.desc}
                    </p>
                    <div className="text-[11px] text-slate-400">
                      <strong>Entrega:</strong> {s.deliverables}
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-white/5 text-xs mt-3">
                    <button
                      onClick={() => setEditingService(s)}
                      className="font-gotham font-bold text-[#D62828] hover:underline cursor-pointer"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(`¿Eliminar el servicio "${s.title}"?`)) {
                          deleteService(s.id);
                          triggerToast('Servicio eliminado.');
                        }
                      }}
                      className="text-rose-500 hover:underline cursor-pointer"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 9. GESTOR DE PREGUNTAS FRECUENTES (FAQS) */}
        {activeTab === 'faqs' && (
          <div className="space-y-6">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div>
                <h2 className="font-gotham text-xl font-black text-[#D62828]">
                  Preguntas Frecuentes (Centro de Respuestas)
                </h2>
                <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                  Gestiona las preguntas y respuestas oficiales mostradas en la página de FAQs.
                </p>
              </div>

              <button
                onClick={() =>
                  setEditingFaq({
                    id: 'faq-' + Date.now(),
                    category: 'kdp',
                    question: 'Nueva Pregunta sobre el proceso KDP',
                    answer: 'Respuesta completa y detallada para orientar al autor.',
                  })
                }
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-bold flex items-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Añadir Pregunta</span>
              </button>
            </div>

            {editingFaq && (
              <div className={`p-6 rounded-2xl border ${isLight ? 'bg-white border-slate-300 shadow-lg' : 'bg-[#141118] border-[#D62828]/50 shadow-xl'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828] mb-4">
                  {config.faqs.some((f) => f.id === editingFaq.id) ? 'Editar Pregunta FAQ' : 'Nueva Pregunta FAQ'}
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mb-4">
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">Pregunta:</label>
                    <input
                      type="text"
                      value={editingFaq.question}
                      onChange={(e) => setEditingFaq({ ...editingFaq, question: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 font-bold"
                    />
                  </div>
                  <div>
                    <label className="block font-gotham font-bold mb-1">Categoría:</label>
                    <select
                      value={editingFaq.category}
                      onChange={(e) => setEditingFaq({ ...editingFaq, category: e.target.value as FAQItem['category'] })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    >
                      <option value="kdp">Amazon KDP & Regalías</option>
                      <option value="diseno">Diseño & Maquetación</option>
                      <option value="tramites">ISBN & Derechos</option>
                      <option value="marketing">Marketing & Bestseller</option>
                      <option value="precios">Plazos & Precios</option>
                    </select>
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block font-gotham font-bold mb-1">Respuesta Detallada:</label>
                    <textarea
                      rows={4}
                      value={editingFaq.answer}
                      onChange={(e) => setEditingFaq({ ...editingFaq, answer: e.target.value })}
                      className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10"
                    />
                  </div>
                </div>

                <div className="flex justify-end gap-2">
                  <button
                    onClick={() => setEditingFaq(null)}
                    className="px-4 py-2 rounded-xl bg-slate-200 dark:bg-white/10 text-xs font-gotham font-bold cursor-pointer"
                  >
                    Cancelar
                  </button>
                  <button
                    onClick={() => {
                      addOrUpdateFaq(editingFaq);
                      setEditingFaq(null);
                      triggerToast('Pregunta FAQ guardada.');
                    }}
                    className="px-5 py-2 rounded-xl bg-gradient-to-r from-[#D62828] to-[#b71c1c] text-white text-xs font-gotham font-black cursor-pointer"
                  >
                    Guardar FAQ
                  </button>
                </div>
              </div>
            )}

            <div className="space-y-3">
              {config.faqs.map((f) => (
                <div
                  key={f.id}
                  className={`p-4 rounded-2xl border flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isLight ? 'bg-white border-slate-200' : 'bg-[#141118] border-white/10'
                  }`}
                >
                  <div className="space-y-1 max-w-2xl">
                    <span className="text-[10px] font-mono uppercase text-[#D62828] font-bold">
                      [{f.category}]
                    </span>
                    <h4 className="font-gotham font-bold text-xs sm:text-sm">{f.question}</h4>
                    <p className={`text-xs ${isLight ? 'text-slate-700' : 'text-slate-400'} line-clamp-2`}>
                      {f.answer}
                    </p>
                  </div>

                  <div className="flex items-center gap-2 flex-shrink-0">
                    <button
                      onClick={() => setEditingFaq(f)}
                      className="px-3 py-1.5 rounded-lg bg-slate-100 dark:bg-white/5 text-xs font-gotham font-bold hover:text-[#D62828] cursor-pointer"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm('¿Deseas eliminar esta pregunta frecuente?')) {
                          deleteFaq(f.id);
                          triggerToast('FAQ eliminada.');
                        }
                      }}
                      className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-500/10 cursor-pointer"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* 10. PLANES Y PRECIOS */}
        {activeTab === 'pricing' && (
          <div className="space-y-6">
            <div>
              <h2 className="font-gotham text-xl font-black text-[#D62828]">
                Tarifas y Títulos de los Planes Editoriales
              </h2>
              <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                Actualiza los precios y nombres de los 3 paquetes de lanzamiento para autores.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Plan Starter */}
              <div className={`p-6 rounded-3xl border space-y-4 ${isLight ? 'bg-white border-slate-300' : 'bg-[#141118] border-white/10'}`}>
                <span className="text-xs font-gotham font-bold text-slate-400 uppercase tracking-wider block">
                  Paquete 1 (Esencial)
                </span>
                <div>
                  <label className="block text-xs font-gotham font-bold mb-1">Nombre del Plan:</label>
                  <input
                    type="text"
                    value={formState.planStarterTitle}
                    onChange={(e) => handleChange('planStarterTitle', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-gotham font-bold mb-1">Precio en USD ($):</label>
                  <input
                    type="number"
                    value={formState.planStarterPrice}
                    onChange={(e) => handleChange('planStarterPrice', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 text-xs font-black"
                  />
                </div>
              </div>

              {/* Plan Pro */}
              <div className={`p-6 rounded-3xl border space-y-4 ring-2 ring-[#D62828]/50 ${isLight ? 'bg-white border-[#D62828]' : 'bg-[#141118] border-[#D62828]'}`}>
                <span className="text-xs font-gotham font-bold text-[#D62828] uppercase tracking-wider block">
                  Paquete 2 (Bestseller Pro)
                </span>
                <div>
                  <label className="block text-xs font-gotham font-bold mb-1">Nombre del Plan:</label>
                  <input
                    type="text"
                    value={formState.planProTitle}
                    onChange={(e) => handleChange('planProTitle', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-gotham font-bold mb-1">Precio en USD ($):</label>
                  <input
                    type="number"
                    value={formState.planProPrice}
                    onChange={(e) => handleChange('planProPrice', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 text-xs font-black text-[#D62828]"
                  />
                </div>
              </div>

              {/* Plan Elite */}
              <div className={`p-6 rounded-3xl border space-y-4 ${isLight ? 'bg-white border-slate-300' : 'bg-[#141118] border-white/10'}`}>
                <span className="text-xs font-gotham font-bold text-slate-400 uppercase tracking-wider block">
                  Paquete 3 (Élite 360)
                </span>
                <div>
                  <label className="block text-xs font-gotham font-bold mb-1">Nombre del Plan:</label>
                  <input
                    type="text"
                    value={formState.planEliteTitle}
                    onChange={(e) => handleChange('planEliteTitle', e.target.value)}
                    className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 text-xs font-bold"
                  />
                </div>
                <div>
                  <label className="block text-xs font-gotham font-bold mb-1">Precio en USD ($):</label>
                  <input
                    type="number"
                    value={formState.planElitePrice}
                    onChange={(e) => handleChange('planElitePrice', Number(e.target.value))}
                    className="w-full px-3 py-2 rounded-xl border bg-slate-50 dark:bg-[#080709] border-slate-300 dark:border-white/10 text-xs font-black"
                  />
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 11. LOGOTIPO */}
        {activeTab === 'logo' && (
          <div className="space-y-6">
            <div>
              <h2 className="font-gotham text-xl font-black text-[#D62828]">
                Gestión del Logotipo de Best Book Marketing
              </h2>
              <p className={`text-xs ${isLight ? 'text-slate-800 font-medium' : 'text-slate-400'}`}>
                Sube tus propios archivos SVG o PNG de marca tanto para el tema oscuro como para el tema claro.
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Logo Blanco */}
              <div className={`p-6 rounded-3xl border space-y-4 ${isLight ? 'bg-white border-slate-300' : 'bg-[#141118] border-white/10'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828]">
                  Logotipo para Fondo Oscuro (Blanco)
                </h3>
                <p className="text-xs text-slate-400">
                  Se muestra en el Header oscuro, Hero y Footer.
                </p>

                <div className="p-6 rounded-2xl bg-[#080709] border border-white/10 flex items-center justify-center min-h-[110px]">
                  {formState.logoWhiteUrl ? (
                    <img
                      src={formState.logoWhiteUrl}
                      alt="Logo Blanco"
                      className="max-h-12 object-contain"
                    />
                  ) : (
                    <BestBookLogo theme="dark" size="md" />
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    ref={whiteLogoInputRef}
                    onChange={(e) => handleLogoUpload(e, 'white')}
                    accept="image/png, image/svg+xml, image/jpeg"
                    className="hidden"
                  />
                  <button
                    onClick={() => whiteLogoInputRef.current?.click()}
                    className="flex-1 py-2.5 rounded-xl bg-[#D62828] text-white text-xs font-gotham font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Subir Logo Blanco</span>
                  </button>
                  {formState.logoWhiteUrl && (
                    <button
                      onClick={() => handleChange('logoWhiteUrl', '')}
                      className="p-2.5 rounded-xl bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 cursor-pointer"
                      title="Quitar logo subido"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Logo Negro */}
              <div className={`p-6 rounded-3xl border space-y-4 ${isLight ? 'bg-white border-slate-300' : 'bg-[#141118] border-white/10'}`}>
                <h3 className="font-gotham font-black text-sm text-[#D62828]">
                  Logotipo para Fondo Claro (Negro)
                </h3>
                <p className="text-xs text-slate-400">
                  Se muestra cuando el usuario activa el tema claro en páginas interiores.
                </p>

                <div className="p-6 rounded-2xl bg-white border border-slate-200 flex items-center justify-center min-h-[110px]">
                  {formState.logoBlackUrl ? (
                    <img
                      src={formState.logoBlackUrl}
                      alt="Logo Negro"
                      className="max-h-12 object-contain"
                    />
                  ) : (
                    <BestBookLogo theme="light" size="md" />
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="file"
                    ref={blackLogoInputRef}
                    onChange={(e) => handleLogoUpload(e, 'black')}
                    accept="image/png, image/svg+xml, image/jpeg"
                    className="hidden"
                  />
                  <button
                    onClick={() => blackLogoInputRef.current?.click()}
                    className="flex-1 py-2.5 rounded-xl bg-slate-900 text-white text-xs font-gotham font-bold flex items-center justify-center gap-2 cursor-pointer"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>Subir Logo Negro</span>
                  </button>
                  {formState.logoBlackUrl && (
                    <button
                      onClick={() => handleChange('logoBlackUrl', '')}
                      className="p-2.5 rounded-xl bg-rose-500/10 text-rose-500 hover:bg-rose-500/20 cursor-pointer"
                      title="Quitar logo subido"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
